// mobina najafi
// 40223081


#include<stdio.h>
#include<string.h>
#include<ctype.h>

struct dictionary{
    char lang1[50];
    char lang2[50];
};

int main(){
    
    int m;
    printf("enter the number of languages:");
    scanf("%d",&m);
    struct dictionary dictionary[m];
    
    for (int i=0 ; i<m ; i++)
        scanf("%s   %s",dictionary[i].lang1,dictionary[i].lang2);
    
    
    char sentence[100];
    
    printf("enter your sentence in first language:");
    getchar();
    gets(sentence);
    
    int k=0,p=0;
    char inputWord[50][50];
   
    for (int i=0 ; i<strlen(sentence) ; i++){
       
        if(sentence[i]==' ' || sentence[i]=='\0'){
            inputWord[k][p]='\0';
            k++;
            p=0;
        }
            
        else{
            inputWord[k][p]=tolower(sentence[i]);
            p++;
        }
        
    }
    
    for (int i=0 ; i<=k ; i++){
       
       for(int j=0 ; j<m ;j++){
           
            if(strcmp(inputWord[i],dictionary[j].lang1)==0 || strcmp(inputWord[i],dictionary[j].lang2)==0){
                
                if(strlen(inputWord[i])<=strlen(dictionary[j].lang2))
                    printf("%s ",dictionary[j].lang1);
                else
                    printf("%s ",dictionary[j].lang2);
            }
        }
    }

}